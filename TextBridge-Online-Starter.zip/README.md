# TextBridge

A small web app for transferring text between a phone and a laptop over the internet.

## Deploy online (Render)

1. Create a GitHub account if you do not have one.
2. Upload all files in this folder to a new GitHub repository.
3. In Render, choose **New → Web Service** and connect that repository.
4. Set:
   - Runtime: **Node**
   - Build command: `npm install`
   - Start command: `npm start`
   - Instance type: Free (if available on your account)
5. Deploy. Open the public `https://...onrender.com` address on both devices.

## How to use

1. Open the site on one device and tap **Create new room**.
2. Copy the 6-character room code.
3. Open the same site on the other device, enter the code, and tap **Join room**.
4. Paste text and tap **Send text**. Received messages appear automatically.

## Limits and privacy

- Maximum 10 MB per message.
- Up to 30 recent messages per room.
- Rooms expire after 1 hour of inactivity.
- Messages are stored in server memory, not a permanent database. A server restart clears them.
- Anyone who knows the room code can join it. Share the code privately.
- Use HTTPS hosting; do not send passwords, OTPs, or confidential information.
- This is a starter implementation. For long-term storage, authentication, encryption at rest, or reliable large-scale use, add a database and stronger access controls.
