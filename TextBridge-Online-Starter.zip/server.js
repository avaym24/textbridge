const express = require("express");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const MAX_TEXT_BYTES = 10 * 1024 * 1024; // 10 MB per message
const ROOM_TTL_MS = 60 * 60 * 1000; // rooms expire after 1 hour
const rooms = new Map();

app.use(express.json({ limit: "11mb" }));
app.use(express.static(path.join(__dirname, "public")));

function cleanExpired() {
  const now = Date.now();
  for (const [code, room] of rooms) {
    if (now - room.updatedAt > ROOM_TTL_MS) rooms.delete(code);
  }
}
setInterval(cleanExpired, 5 * 60 * 1000).unref();

function validCode(code) {
  return typeof code === "string" && /^[A-Z0-9]{6}$/.test(code);
}

app.post("/api/room", (_req, res) => {
  cleanExpired();
  let code;
  do {
    code = crypto.randomBytes(4).toString("hex").slice(0, 6).toUpperCase();
  } while (rooms.has(code));
  rooms.set(code, { messages: [], updatedAt: Date.now() });
  res.json({ code });
});

app.get("/api/room/:code", (req, res) => {
  const code = req.params.code.toUpperCase();
  if (!validCode(code)) return res.status(400).json({ error: "Invalid room code." });
  const room = rooms.get(code);
  if (!room) return res.status(404).json({ error: "Room not found or expired." });
  room.updatedAt = Date.now();
  res.json({ messages: room.messages });
});

app.post("/api/room/:code/message", (req, res) => {
  const code = req.params.code.toUpperCase();
  if (!validCode(code)) return res.status(400).json({ error: "Invalid room code." });
  const room = rooms.get(code);
  if (!room) return res.status(404).json({ error: "Room not found or expired." });

  const text = req.body && req.body.text;
  const sender = req.body && req.body.sender;
  if (typeof text !== "string") return res.status(400).json({ error: "Text is required." });
  if (Buffer.byteLength(text, "utf8") > MAX_TEXT_BYTES) {
    return res.status(413).json({ error: "Text is too large. Maximum is 10 MB per message." });
  }

  const message = {
    id: crypto.randomUUID(),
    sender: sender === "Laptop" ? "Laptop" : "Mobile",
    text,
    createdAt: Date.now()
  };
  room.messages.push(message);
  if (room.messages.length > 30) room.messages.shift();
  room.updatedAt = Date.now();
  res.json({ ok: true, id: message.id });
});

app.get("/health", (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => console.log(`TextBridge running on port ${PORT}`));
